# Game Project

This is a cleaned, Netlify- and Vercel-ready project.

## Deployment on Vercel

1. Push this repository to GitHub.
2. Go to [Vercel](https://vercel.com) and create a new project.
3. Import the GitHub repository.
4. Build settings:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Output directory: `dist`
   - Node version: 18 (Vercel uses 18 by default)
5. Deploy 🚀

## Local Development

```bash
npm install
npm run dev
```

Build for production:

```bash
npm run build
```
