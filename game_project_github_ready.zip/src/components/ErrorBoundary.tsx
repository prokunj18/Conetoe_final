import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface State { hasError: boolean; error: any; info: any; }

export class ErrorBoundary extends React.Component<React.PropsWithChildren<{}>, State> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false, error: null, info: null };
  }
  static getDerivedStateFromError(error: any) {
    return { hasError: true, error, info: null };
  }
  componentDidCatch(error: any, info: any) {
    console.error('ErrorBoundary caught:', error, info);
    this.setState({ hasError: true, error, info });
  }
  render() {
    if (this.state.hasError) {
      const err = this.state.error;
      const stack = this.state.info?.componentStack || (err && err.stack) || 'No stack available';
      return (
        <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-950 text-white">
          <div className="max-w-2xl w-full bg-surface/80 backdrop-blur p-6 rounded-2xl shadow-lg">
            <h2 className="text-2xl font-bold mb-2">Something went wrong</h2>
            <p className="text-sm text-muted-foreground mb-4">The game encountered an error while loading. The error is shown below — you can copy it and paste it here so I can fix it.</p>
            <pre className="text-xs p-3 bg-black/60 rounded mb-4 overflow-auto" style={{maxHeight: '40vh'}}>{String(err && err.toString())}\n\n{String(stack)}</pre>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => window.location.href = '/'}>Back to Menu</Button>
              <Button onClick={() => window.location.reload()}>Reload</Button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children as any;
  }
}
export default ErrorBoundary;
