import React from 'react';
import { useSettings } from "@/contexts/SettingsContext";
import { getConeGradient } from "@/utils/coneGradients";

interface ConePreviewProps {
  player: number;
  size: number;
  className?: string;
}

export const ConePreview = ({ player, size, className = "" }: ConePreviewProps) => {
  const { coneStyle, boardTheme } = useSettings();

  const getConeStyleGradient = (player: number) => {
    const styleMap = {
      classic: player === 1 ? "linear-gradient(135deg, #22d3ee, #2563eb)" : "linear-gradient(135deg, #f472b6, #9333ea)",
      fire: player === 1 ? "linear-gradient(135deg, #ef4444, #ea580c)" : "linear-gradient(135deg, #eab308, #ef4444)",
      emerald: player === 1 ? "linear-gradient(135deg, #34d399, #16a34a)" : "linear-gradient(135deg, #06b6d4, #34d399)",
      galaxy: player === 1 ? "linear-gradient(135deg, #a855f7, #db2777)" : "linear-gradient(135deg, #6366f1, #a855f7)",
      golden: player === 1 ? "linear-gradient(135deg, #facc15, #f97316)" : "linear-gradient(135deg, #f59e0b, #facc15)",
      arctic: player === 1 ? "linear-gradient(135deg, #bfdbfe, #22d3ee)" : "linear-gradient(135deg, #cbd5e1, #3b82f6)",
      shadow: player === 1 ? "linear-gradient(135deg, #4b5563, #000000)" : "linear-gradient(135deg, #6b7280, #374151)",
      rainbow: "linear-gradient(135deg, #ef4444, #eab308, #22c55e, #3b82f6)",
      chrome: player === 1 ? "linear-gradient(135deg, #d1d5db, #6b7280)" : "linear-gradient(135deg, #9ca3af, #4b5563)",
      plasma: player === 1 ? "linear-gradient(135deg, #f472b6, #9333ea)" : "linear-gradient(135deg, #8b5cf6, #f472b6)"
    }
    return styleMap[coneStyle] || styleMap.classic;
  }

  const getConeSize = (size: number) => {
    switch (size) {
      case 1: return "w-4 h-4";
      case 2: return "w-5 h-5";
      case 3: return "w-6 h-6";
      case 4: return "w-7 h-7";
      default: return "w-4 h-4";
    }
  }

  return (
    <div 
      className={`hover:scale-105 transition-transform duration-200 ` + {`${getConeSize(size)} relative ${className}`}
      style={{ background: isOpponent ? `linear-gradient(135deg, ${color}, ${color}CC)` : `linear-gradient(135deg, ${color}, ${color}99)` }}
      className={`hover:scale-105 transition-transform duration-200 ` + {`relative ${player === 2 ? 'ring-2 ring-offset-2 ring-white/10' : ''}`}
    >
      <div 
        className={`hover:scale-105 transition-transform duration-200 ` + "absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-black/20"
        style={{ clipPath: 'polygon(50% 5%, 5% 95%, 95% 95%)' }}
      />
      <span className={`hover:scale-105 transition-transform duration-200 ` + "absolute inset-0 flex items-center justify-center text-white font-bold text-xs translate-y-0.5">
        {size}
      </span>
    </div>
  );
}