export type ConeVariant = 'player' | 'opponent';

export const getConeGradient = (styleKey: string | undefined, variant: ConeVariant = 'player'): string => {
  const s = (styleKey || 'classic').toLowerCase();
  const map: { [k: string]: [string, string] } = {
    classic: ['linear-gradient(135deg, #22d3ee, #2563eb)', 'linear-gradient(135deg, #0369a1, #1e3a8a)'],
    fire: ['linear-gradient(135deg, #ff6b6b, #ff8a65)', 'linear-gradient(135deg, #7f1d1d, #b91c1c)'],
    golden: ['linear-gradient(135deg, #f59e0b, #f97316)', 'linear-gradient(135deg, #b45309, #92400e)'],
    forest: ['linear-gradient(135deg, #22c55e, #15803d)', 'linear-gradient(135deg, #065f46, #064e3b)'],
    purple: ['linear-gradient(135deg, #a855f7, #7e22ce)', 'linear-gradient(135deg, #581c87, #3b0764)']
  };
  const pair = map[s] || map['classic'];
  return variant === 'player' ? pair[0] : pair[1];
};
